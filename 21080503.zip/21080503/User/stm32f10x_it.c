/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTI
  
  AL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
#ifdef fire
extern void TimingDelay_Decrement(void);
void SysTick_Handler(void)
{
	TimingDelay_Decrement();
}
#else
void SysTick_Handler(void)
{
}
#endif
/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 
/****************To configure the Irq_Priority*******************/
#include "bsp_TimGp.h" 

static void TIM1_NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure; 
													
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;	  
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

static void TIM4_NVIC_Configuration(void)//key_value scanner
{
	NVIC_InitTypeDef NVIC_InitStructure; 
													
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;	  
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

static void ADC1_DMA_NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitADC_DMA;

	NVIC_InitADC_DMA.NVIC_IRQChannel = DMA1_Channel1_IRQn;
	NVIC_InitADC_DMA.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitADC_DMA.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitADC_DMA.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitADC_DMA);
}

static void ADC_DOG_NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = ADC1_2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

static void USART2_NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void SetIrq_Priority(void)
{
	/* Configure four bit for preemption priority */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	/*************************/
	TIM1_NVIC_Configuration();
	TIM4_NVIC_Configuration();
	ADC1_DMA_NVIC_Configuration();
	ADC_DOG_NVIC_Configuration();
	USART2_NVIC_Configuration();
}

/**
  * @brief  This function handles EXTI Handler.
  * @param  None
  * @retval None
  */
/****************************************************************/

/**
  * @brief  This function handles TIM1 interrupt request.
  * @param  None
  * @retval None
  */
#include "bsp_AdvTim.h"
void TIM1_UP_IRQHandler(void)
{
//	static volatile uint16_t table_index = 0;
	if (TIM_GetITStatus(TIM1, TIM_IT_Update)) 
	{	
//		TIM_pwm_duty(TIM1, TIM_CH1, (uint16_t)(sinwave_table[table_index]+500));
//		TIM_pwm_duty(TIM1, TIM_CH2, (uint16_t)(sinwave_table[table_index]+500));
//		TIM_pwm_duty(TIM1, TIM_CH3, (uint16_t)(sinwave_table[table_index]+500));
//		if(++table_index > (POINT_NUM_FULL_PERIOD-1)) {
//			table_index = 0;
//		}
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);		
	}		 	
}

/**
  * @brief  This function handles TIM4 interrupt request.
  * @param  None
  * @retval None
  */
#include "bsp_key.h" 
extern uint8_t show_task;
void TIM4_IRQHandler(void)//5ms
{
	static __IO uint16_t cnt_5ms = 0;
	if (TIM_GetITStatus(TIM4, TIM_IT_Update))
	{	
		if(++cnt_5ms%600==0) {
			show_task = 1;
			cnt_5ms = 0;
		} 
		/*********key process***********/
		KeyBoardScan();//Independent keyboard
		IndependentKeyDealPro();/* Independent keyboard */ 		
		/*******************************/
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);		
	}		 	
}

#include "bsp_adc.h"
void DMA1_Channel1_IRQHandler(void)
{
	if(DMA_GetITStatus(DMA1_IT_TC1))
	{
		DMA_Cmd(DMA1_Channel1,DISABLE);
		Que();//lvbo
		DMA_Cmd(DMA1_Channel1,ENABLE);   
		DMA_ClearITPendingBit(DMA1_IT_GL1);
	}
}

void ADC1_2_IRQHandler(void)
{
	if(ADC_GetFlagStatus(ADC1, ADC_FLAG_AWD))
	{
		ADC_ClearITPendingBit(ADC1, ADC_IT_AWD);
	}
}

#include "syn6288.h"
static char u2recdat;
char ledstate=0;
//�����жϣ�������Ӧsyn6288��������
void USART2_IRQHandler()
{
	if(USART_GetITStatus(USART2,USART_IT_RXNE)!= RESET) //ȷ���Ƿ�������ж�  
	{  	
		u2recdat=USART_ReceiveData(USART2);
		if(u2recdat==SYN6288_ACK_IDLE)
		{		
			syn_state=0;//idle
		}
	}
}
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
