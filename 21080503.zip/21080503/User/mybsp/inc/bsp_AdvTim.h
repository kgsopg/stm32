#ifndef __BSP_ADVTIM_H__
#define __BSP_ADVTIM_H__

#include "stm32f10x.h"

#define MOD_FREQ  (15*1000)

//����TIM1-5,TIM8��ͨ����
typedef enum
{
    TIM_CH1 = 1,
    TIM_CH2,
    TIM_CH3,
    TIM_CH4,
} TIM_CHn_e;

extern void ADVANCE_TIM1_PWM_Init(void);
extern void TIM_pwm_duty(TIM_TypeDef* TIMx, TIM_CHn_e ch, uint16_t duty);

#endif	/* __BSP_ADVTIM_H */


