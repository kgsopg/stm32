/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DS18B20_H__
#define __DS18B20_H__ 

#include "stm32f10x.h"
#include "bsp_SysTick.h"

#define HIGH  1
#define LOW   0

#define DS18B20_CLK     RCC_APB2Periph_GPIOA
#define DS18B20_PIN     GPIO_Pin_15                
#define DS18B20_PORT	GPIOB

#define DS18B20_DATA_OUT(a)	if (a)	\
								GPIO_SetBits(DS18B20_PORT, DS18B20_PIN );\
							else	\
								GPIO_ResetBits(DS18B20_PORT, DS18B20_PIN )
 //��ȡ���ŵĵ�ƽ
#define  DS18B20_DATA_IN()	GPIO_ReadInputDataBit(DS18B20_PORT, DS18B20_PIN)

uint8_t DS18B20_Init(void);
float DS18B20_Get_Temp(void);

#endif /* __DS18B20_H */ 
