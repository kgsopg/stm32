#ifndef __BSP_BEEP_H__
#define __BSP_BEEP_H__

#include "stm32f10x.h"
#include "bsp_SysTick.h"

extern void BEEP_Init(void);
extern void beep_change(uint8_t period);//0:always_off; 1:always_on; other:change_on_off

#endif
