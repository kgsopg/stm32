#ifndef __BSP_ADC_H__
#define	__BSP_ADC_H__

#include "stm32f10x.h"

#define NOFCHANEL 1
#define SAMPLING_SIZE 10
#define ADC1_BufferLength NOFCHANEL*SAMPLING_SIZE
#define ADC1_DR_Address  ((uint32_t)0x40012400+0x4c)	

extern __IO uint32_t ADC_ConvertedValue[ADC1_BufferLength];
extern void ADC12_Init(void);
extern void Que(void);


#endif /* __ADC_H */

