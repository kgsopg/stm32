#ifndef __BSP_TIMGP_H__
#define	__BSP_TIMGP_H__

#include "stm32f10x.h"

extern void TIM3_PWM_Init(void);
extern void TIM4_1msIRQ_Config(uint8_t count);

#endif /* __BSP_TIMGP_H__ */

