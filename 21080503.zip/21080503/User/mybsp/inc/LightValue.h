#ifndef __LIGHTVALUE_H
#define	__LIGHTVALUE_H
#include "stm32f10x.h"

#include  <math.h>    //Keil library  
#include  <stdio.h>   //Keil library
void I2C_LV_Init(void);
void I2C_LV_Write(u16 RegValue);
u16 I2C_LV_Read(void);

#endif

