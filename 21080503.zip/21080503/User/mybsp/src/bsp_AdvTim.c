#include "bsp_AdvTim.h"
#include "math.h"

//#define TIM1_CCR1_Address    0x40012C34	//����CCP1��ַ
//#define TIM1_CCR2_Address    0x40012C38	//����CCP2��ַ

static void ADVANCE_TIM1_GPIO_Config(void) 
{
	GPIO_InitTypeDef GPIO_InitStructure;
	/* TIM1 GPIO_FullRemap clock enable */
//	GPIO_PinRemapConfig(GPIO_FullRemap_TIM1, ENABLE);
	
	/* GPIOA clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	/*GPIOA Configuration: TIM1 channel 1, channel2, channel3 as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_ResetBits(GPIOC, GPIO_Pin_13); 
	
}

/* Compute the value to be set in ARR register to generate signal frequency at x kHz */
#define TimerPeriod_adv (uint16_t)((SystemCoreClock / MOD_FREQ) - 1)//MOD_FREQ Hz

static void ADVANCE_TIM1_Mode_Config(uint16_t Channel1Pulse, uint16_t Channel2Pulse, uint16_t Channel3Pulse)//ע�⣺ch4û�л���ͨ��
{
	uint16_t CCR1_Val = 0;
	uint16_t CCR2_Val = 0;
	uint16_t CCR3_Val = 0;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    /* ----------------------------------------------------------------------- 
	TIM1 Channel1 duty cycle = (TIM1_CCR1/ TIM1_ARR+1)* 100% = %
	----------------------------------------------------------------------- */
	/* Compute CCR1 value to generate a duty cycle at 0% for channel 1 */  
	CCR1_Val = (uint16_t) (((uint32_t) Channel1Pulse * (TimerPeriod_adv - 1)) / 1000);//����1000
	CCR2_Val = (uint16_t) (((uint32_t) Channel2Pulse * (TimerPeriod_adv - 1)) / 1000);
	CCR3_Val = (uint16_t) (((uint32_t) Channel3Pulse * (TimerPeriod_adv - 1)) / 1000);
	
	/* Time base configuration */
	TIM_TimeBaseStructure.TIM_Period = TimerPeriod_adv;	
	TIM_TimeBaseStructure.TIM_Prescaler = 0;//(SystemCoreClock / 72000000) - 1 = 0
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;		
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;		
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;	
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

	/* PWM1 Mode configuration: Channel1, Channel2 and Channel3 */
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

	TIM_OCInitStructure.TIM_Pulse = CCR1_Val;
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);//Disable���������£�����

    TIM_OCInitStructure.TIM_Pulse = CCR2_Val;
    TIM_OC2Init(TIM1, &TIM_OCInitStructure);//��channel2�������� 
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
	TIM_OCInitStructure.TIM_Pulse = CCR3_Val;
    TIM_OC3Init(TIM1, &TIM_OCInitStructure);//��channel3�������� 
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);

	TIM_ARRPreloadConfig(TIM1, ENABLE);			  //ʹ��TIM1��ARR�ϵ�Ԥװ�ؼĴ���

    /* TIM1 counter enable */
	TIM_Cmd(TIM1, ENABLE);	
	TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
    /* Main Output Enable */
	TIM_CtrlPWMOutputs(TIM1, ENABLE);
}

void ADVANCE_TIM1_PWM_Init(void)
{
	ADVANCE_TIM1_GPIO_Config();
	ADVANCE_TIM1_Mode_Config(1000, 1000, 1000);		
}

void TIM_pwm_duty(TIM_TypeDef* TIMx, TIM_CHn_e ch, uint16_t duty)
{ 
	/* Check the parameters */
    assert_param(IS_TIM_LIST6_PERIPH(TIMx));
    /* Set the Capture Comparex Register value */
	/* Compute the value to be set in ARR register to generate signal frequency at x kHz */
	duty = (uint16_t) (((uint32_t) duty * (TimerPeriod_adv - 1)) / 1000);//����1000;
	switch(ch)
	{
		case TIM_CH1:
			TIMx->CCR1 = duty;
			break;
		case TIM_CH2:
			TIMx->CCR2 = duty;
			break;
		case TIM_CH3:
			TIMx->CCR3 = duty;
			break;
		case TIM_CH4:
			TIMx->CCR4 = duty;
			break;
		default:
			break;			
	}
}
/*********************************************END OF FILE**********************/
