#include "bsp_usart.h"
#include "bsp_TimGp.h" 

static void TIM3_GPIO_Config(void) 
{
	GPIO_InitTypeDef GPIO_InitStructure;
	/* GPIOB clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); 
	/* GPIOB Configuration: TIM3 channel 3 and 4 as alternate function push-pull */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

static void TIM3_Mode_Config(uint16_t Channel3Pulse, uint16_t Channel4Pulse)//3��4ͨ����ռ�ձ�
{
	uint16_t CCR3_Val = 0, CCR4_Val = 0;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); 

	/* ----------------------------------------------------------------------- 
	TIM3 Channel3 duty cycle = (TIM3_CCR3/ TIM3_ARR+1)* 100% = %
	TIM3 Channel4 duty cycle = (TIM3_CCR4/ TIM3_ARR+1)* 100% = %
	----------------------------------------------------------------------- */
	/* Compute CCR3 value to generate a duty cycle at 50% for channel 3 */  
	CCR3_Val = Channel3Pulse;
	CCR4_Val = Channel4Pulse;

	/* Time base configuration */		 
	TIM_TimeBaseStructure.TIM_Period = 999;   
	TIM_TimeBaseStructure.TIM_Prescaler = 719;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1 ;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

	/* PWM1 Mode configuration: Channel3 */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;	
	TIM_OCInitStructure.TIM_Pulse = CCR3_Val;	                 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;    
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);	                
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);

	/* PWM1 Mode configuration: Channel4 */
	TIM_OCInitStructure.TIM_Pulse = CCR4_Val;	
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);	
	TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);

	TIM_ARRPreloadConfig(TIM3, ENABLE);			 
	/* TIM3 enable counter */
	TIM_Cmd(TIM3, ENABLE);                   
}

/**
  * @brief  TIM3 ���PWM�źų�ʼ��
  * @param  none
  * @retval none
  */
void TIM3_PWM_Init(void)
{
	TIM3_GPIO_Config();
	TIM3_Mode_Config(100, 0);	//50Hz
}

void TIM4_1msIRQ_Config(uint8_t count)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	//TIM_DeInit(TIM4);
	//�ж�����Ϊ = 1/(72MHZ/72) * 1000 = 1ms
	TIM_TimeBaseStructure.TIM_Period = (1000*count-1);
	TIM_TimeBaseStructure.TIM_Prescaler = (72-1);
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_ClearFlag(TIM4, TIM_FLAG_Update);
	TIM_ITConfig(TIM4,TIM_IT_Update, ENABLE);
	TIM_Cmd(TIM4, ENABLE);																		
	//RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, DISABLE);/*�ȹرյȴ�ʹ��*/
	//RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);    
}

/*********************************************END OF FILE**********************/
