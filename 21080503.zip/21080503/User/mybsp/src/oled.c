#include "oled.h" 
#include "oled_table.h"	

static void SPI1_Configuration(void)
{
	SPI_InitTypeDef  SPI_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd( RCC_APB2Periph_SPI1 | RCC_APB2Periph_OLED_PORT, ENABLE);

	/* NSS---->GPIO(LED) */
	SPI_SSOutputCmd(SPI1, ENABLE);

	GPIO_InitStructure.GPIO_Pin = OLED_SCK_PIN | OLED_SDA_PIN ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(OLED_PORT, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = OLED_RST_PIN | OLED_DC_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(OLED_PORT, &GPIO_InitStructure);

	/* SPI1 Config -------------------------------------------------------------*/
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);
	/* Enable SPI1 */
	SPI_Cmd(SPI1, ENABLE);
}

void OLED_WB(uint8_t data)
{
	/* Loop while DR register in not emplty */
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
	/* Send byte through the SPI1 peripheral */
	SPI_I2S_SendData(SPI1, data);
	Delay_us(2);
}
/*******************һ���ֽ�����д��***********************/
void OLED_WrDat(uint8_t data)
{
	OLED_DC_H;
	OLED_WB(data);
}

/********************һ��ָ��д��**********************/
void OLED_WrCmd(uint8_t cmd)
{
	OLED_DC_L;
	OLED_WB(cmd);
}

/**********************������ʾλ��**********************/
void OLED_Set_Pos(uint8_t x, uint8_t y)
{
	/* Page addressing mode */
	OLED_WrCmd(0xb0+(y&0x07));/* set page start address */
	OLED_WrCmd(x&0x0f);/* set lower nibble of the column address */
	OLED_WrCmd(((x&0xf0)>>4)|0x10); /* set higher nibble of the column address */
}

/**********************д��������**********************/
void OLED_Fill(unsigned char bmp_dat)
{
	unsigned char y,x;
	OLED_WrCmd(0x20);//-Set Page Addressing Mode (0x00/0x01/0x02)
	OLED_WrCmd(0x00);//
	OLED_WrCmd(0x21);//-Set Column Address
	OLED_WrCmd(0x00);
	OLED_WrCmd(0x7f);
	OLED_WrCmd(0x22);//-Set Page Address
	OLED_WrCmd(0x00);
	OLED_WrCmd(0x07);
	OLED_DLY_ms(1);/* �ȴ��ڲ��ȶ�   */
	for(y=0;y<Page;y++)
	{
		for(x=0;x<X_WIDTH;x++)
		{
			OLED_WrDat(bmp_dat);
		}
	}
	//    LCD_WrCmd(0xaf);//--turn off oled panel
}

/*********************��������***********************/
void OLED_CLS(void)
{
	unsigned char y,x;
	for(y=0;y<8;y++)
	{
		OLED_WrCmd(0xb0+y);
		OLED_WrCmd(0x01);
		OLED_WrCmd(0x10);
		for(x=0;x<X_WIDTH;x++)
		OLED_WrDat(0);
		OLED_DLY_ms(200);
	}
}

/*********************��ʱ����***********************/
void OLED_DLY_ms(unsigned int ms)
{
	unsigned int a;
	while(ms)
	{
		a=1335;
		while(a--);
		ms--;
	}
	return;
}

/*********************12864��ʼ��***********************/
void OLED_Init(void)
{
	SPI1_Configuration();
	OLED_RST_L;
	OLED_DLY_ms(50);
	OLED_RST_H;
	//���ϵ絽���濪ʼ��ʼ��Ҫ���㹻��ʱ�䣬���ȴ�RC��λ���

	OLED_WrCmd(0xae);//--turn off oled panel

	OLED_WrCmd(0xa8);//--set multiplex ratio(1 to 64)
	OLED_WrCmd(0x3f);//--1/64 duty
	OLED_WrCmd(0xd3);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	OLED_WrCmd(0x00);//-not offset
	OLED_WrCmd(0x40);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	OLED_WrCmd(0xa1);//--Set SEG/Column Mapping     0xa0���ҷ��� 0xa1����
	OLED_WrCmd(0xc8);//Set COM/Row Scan Direction   0xc0���·��� 0xc8����
	OLED_WrCmd(0xda);//--set com pins hardware configuration
	OLED_WrCmd(0x12);
	OLED_WrCmd(0x81);//--set contrast control register
	OLED_WrCmd(0xcf); // Set SEG Output Current Brightness
	OLED_WrCmd(0xa4);// Disable Entire Display On (0xa4/0xa5)
	OLED_WrCmd(0xa6);// Disable Inverse Display On (0xa6/a7)
	OLED_WrCmd(0xd5);//--set display clock divide ratio/oscillator frequency
	OLED_WrCmd(0x80);//--set divide ratio, Set Clock as 100 Frames/Sec
	OLED_WrCmd(0x8d);//--set Charge Pump enable/disable
	OLED_WrCmd(0x14);//--set(0x10) disable
	OLED_WrCmd(0xaf);//--turn on oled panel

	OLED_WrCmd(0xd9);//--set pre-charge period
	OLED_WrCmd(0xf8);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock

	OLED_WrCmd(0xdb);//--set vcomh
	OLED_WrCmd(0x40);//Set VCOM Deselect Level

	OLED_Fill(0x00);  //��ʼ����
}
/***************������������ʾ6*8һ���׼ASCII�ַ���	��ʾ�����꣨x,y����yΪҳ��Χ0��7****************/
void OLED_P6x8Str(unsigned char x,unsigned char y,unsigned char ch[])
{
	unsigned char c=0,i=0,j=0;      
	while (ch[j]!='\0')
	{    
		c =ch[j]-32;
		if(x>126){x=0;y++;}
		OLED_Set_Pos(x,y);    
		for(i=0;i<6;i++)     
		OLED_WrDat(F6x8[c][i]);  
		x+=6;
		j++;
	}
}
/*******************������������ʾ8*16һ���׼ASCII�ַ���	 ��ʾ�����꣨x,y����yΪҳ��Χ0��7****************/
void OLED_P8x16Str(unsigned char x,unsigned char y,unsigned char ch[])
{
	unsigned char c=0,i=0,j=0;
	while (ch[j]!='\0')
	{    
		c =ch[j]-32;
		if(x>120){x=0;y++;}
		OLED_Set_Pos(x,y);    
		for(i=0;i<8;i++)     
		OLED_WrDat(F8X16[c*16+i]);
		OLED_Set_Pos(x,y+1);    
		for(i=0;i<8;i++)     
		OLED_WrDat(F8X16[c*16+i+8]);  
		x+=8;
		j++;
	}
}
/**********************************************************
�������ƣ�LCD_P14x16Str
�������ܣ�д��һ�麺�� 
��ڲ�������ʾ��λ�ã�x,y���������ַ���
���ڲ�������  
***********************************************************/
void OLED_P14x16Str(unsigned char x,unsigned char y,unsigned char ch[])
{
	unsigned char wm=0,ii = 0;
	unsigned int adder=1; 
  
	while(ch[ii] != '\0')
	{
		wm = 0;
		adder = 1;
		while(F14x16_Idx[wm] > 127)
		{
			if(F14x16_Idx[wm] == ch[ii])
			{
			if(F14x16_Idx[wm + 1] == ch[ii + 1])
			{
				adder = wm * 14;
				break;
			}
		}
		wm += 2;			
		}
		if(x>118) {
			x=0;y++;
		}
		OLED_Set_Pos(x , y); 
		if(adder != 1)// ��ʾ����					
		{
			OLED_Set_Pos(x , y);
			for(wm = 0;wm < 14;wm++)               
			{
				OLED_WrDat(F14x16[adder]);	
				adder += 1;
			}      
			OLED_Set_Pos(x,y + 1); 
			for(wm = 0;wm < 14;wm++)          
			{
				OLED_WrDat(F14x16[adder]);
				adder += 1;
			}   		
		} else {		  //��ʾ�հ��ַ�
			ii += 1;
			OLED_Set_Pos(x,y);
			for(wm = 0;wm < 16;wm++)
			{
				OLED_WrDat(0);
			}
			OLED_Set_Pos(x,y + 1);
			for(wm = 0;wm < 16;wm++)
			{   		
				OLED_WrDat(0);	
			}
		}
		x += 14;
		ii += 2;
	}
}

//������ֺ��ַ�����ַ���
void OLED_Print(unsigned char x, unsigned char y, unsigned char ch[])
{
  unsigned char ch2[3];
  unsigned char ii=0;        
  while(ch[ii] != '\0')
  {
    if(ch[ii] > 127)
    {
      ch2[0] = ch[ii];
      ch2[1] = ch[ii + 1];
      ch2[2] = '\0';			//����Ϊ�����ֽ�
      OLED_P14x16Str(x , y, ch2);	//��ʾ����
      x += 14;
      ii += 2;
    }
    else
    {
      ch2[0] = ch[ii];	
      ch2[1] = '\0';			//��ĸռһ���ֽ�
      OLED_P8x16Str(x , y , ch2);	//��ʾ��ĸ
      x += 8;
      ii+= 1;
    }
  }
} 

/**********************************************************
�������ƣ�OLED_Print_num_int
�������ܣ���Ļ��ӡ�������ֺ��� 
��ڲ���������x,y  ����numС
���ڲ�������  
���ڣ�2016_02_19
***********************************************************/
void OLED_Print_num_int(unsigned char x, unsigned char y, int num)
{  
//	char NUM[8] = {0};
//	unsigned char c = 0, i = 0, j = 0;
//	sprintf (NUM, "%d", num);
//	while (NUM[j]!='\0') {    
//	    c = NUM[j] - 32;
//	    if (x>126) {x = 0; y++;}
//	    OLED_Set_Pos(x,y);    
//	  	for (i = 0; i < 6; i++)    
//            OLED_WrDat(F6x8[c][i]);  
//	  	x+=6;
//	  	j++;
//	}
    char a[6]={0}; 
    if(num<0)
    {
        a[0]='-';
        num=-num;
    }
    else
        a[0]=' ';
	if(num<10) {
        a[1]=num%10;
        a[2]=' ';
        a[3]=' ';
		a[4]=' ';
		a[5]=' ';		
	}else if(num<100) {
		a[1]=num%100/10;
        a[2]=num%10;
        a[3]=' ';
		a[4]=' ';
		a[5]=' ';	
	}else if(num<1000) {
		a[1]=num%1000/100;
        a[2]=num%100/10;
        a[3]=num%10;
		a[4]=' ';
		a[5]=' ';	
	}else if(num<10000) {
		a[1]=num%10000/1000;
        a[2]=num%1000/100;
        a[3]=num%100/10;
		a[4]=num%10;
		a[5]=' ';	
	}else {
        a[1]=num/10000;
        a[2]=num%10000/1000;
        a[3]=num%1000/100;
		a[4]=num%100/10;
		a[5]=num%10;
	}
    for(uint8_t j=0;j<6;j++)
    {
        switch(a[j])
        {
           case 0:{OLED_P6x8Str(x,y,"0");}break;
           case 1:{OLED_P6x8Str(x,y,"1");}break;
           case 2:{OLED_P6x8Str(x,y,"2");}break;
           case 3:{OLED_P6x8Str(x,y,"3");}break;
           case 4:{OLED_P6x8Str(x,y,"4");}break;
           case 5:{OLED_P6x8Str(x,y,"5");}break;
           case 6:{OLED_P6x8Str(x,y,"6");}break;
           case 7:{OLED_P6x8Str(x,y,"7");}break;
           case 8:{OLED_P6x8Str(x,y,"8");}break;
           case 9:{OLED_P6x8Str(x,y,"9");}break; 
           case '-':{OLED_P6x8Str(x,y,"-");}break;
           case ' ':{OLED_P6x8Str(x,y," ");}break;
           default:break;
      }
      x+=6;
      if(x==128)
          x=0;
    }	
}
/**********************************************************
�������ƣ�OLED_Print_num_float
�������ܣ���Ļ��ӡ���������ֺ��� 
��ڲ���������x,y  ����numС,��С�����λ��
���ڲ�������  
���ڣ�2016_02_20
***********************************************************/
void OLED_Print_num_float(unsigned char x, unsigned char y, float num_double, unsigned char presicion)
{
	char NUM[8] = {0};
	int num_int, i, Count = 0, data;
    /*
	if(num_double > 255.0)
		num_double = 255.0;
	else if(num_double < -255.0)
		num_double = -255.0;
	*/
	OLED_Set_Pos(x,y);
	if (num_double < 0) {
		num_double = -num_double;
		for(i = 0; i < 6; i++)     
	  	OLED_WrDat(F6x8[13][i]);//���� 
	  	x+=6;
	} else {
		for(i = 0; i < 6; i++)     
	  	OLED_WrDat(F6x8[0][i]);//space 
	  	x+=6;
	}
		
	num_int = (int)num_double;//�洢����
	//��������
	sprintf(NUM, "%d", num_int);
	while (NUM[Count]!='\0') {    
	  	Count++;
	}
	NUM[Count] = '.';
	Count++;
	for(i = 0; i < presicion; i++) {///presicion���ȵ���
		num_double = num_double * 10;
		data = ((int)num_double)%10;
		NUM[Count] = 48 + data;
		Count++;	
	}
	Count = 0;
	//��ӡ����
	while (NUM[Count]!='\0') {    
	    data = NUM[Count]-32;
	    if(x > 126){x = 0; y++;}
	    OLED_Set_Pos(x,y);    
	  	for(i = 0; i < 6; i++)     
            OLED_WrDat(F6x8[data][i]);  
	  	x+=6;
	  	Count++;
	}	
}
