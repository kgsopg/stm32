#include "bsp_key.h" 
#include "bsp_led.h"
#include "bsp_SysTick.h"
KEY_Flags gKey_Flags;
static void KeyVarInit(void)
{
	gKey_Flags.KeyValue 	= KEY_VALUE_NULL;
	gKey_Flags.LastKeyValue	= KEY_VALUE_NULL;
	gKey_Flags.KeyState 	= KEY_Sate_NULL;
	gKey_Flags.KeyCnt		= KEY_SCAN_NULL;
	gKey_Flags.KeyDealFlag	= KEY_VALUE_NEW_NULL;
	gKey_Flags.KeyOverTime	= 0x00;
	gKey_Flags.KeyDebugData	= 0x00;
}

void Key_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(KEY_GPIO_CLK1|KEY_GPIO_CLK2, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = KEY0_PIN|KEY1_PIN/*|KEY2_PIN|KEY3_PIN*/; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;/*GPIO_Mode_IN_FLOATING*/; 
	GPIO_Init(KEY_GPIO_PORT1, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = KEY2_PIN;
	GPIO_Init(KEY_GPIO_PORT2, &GPIO_InitStructure);
	
	KeyVarInit(); 
}

static uint16_t KeyValueScan(void)
{
	uint16_t RetValue = KEY_VALUE_NULL;
	if(GPIO_ReadInputDataBit(KEY_GPIO_PORT1,KEY0_PIN) == KEY_ON){
		RetValue |= KEY_VALUE_ONE;
	}
	if(GPIO_ReadInputDataBit(KEY_GPIO_PORT1,KEY1_PIN) == KEY_ON){
		RetValue |= KEY_VALUE_TWO;
	}
	if(GPIO_ReadInputDataBit(KEY_GPIO_PORT2,KEY2_PIN) == KEY_ON){
		RetValue |= KEY_VALUE_THREE;
	}
	return (RetValue);
}

void KeyBoardScan(void)
{
	uint16_t GetValueTemp;
	GetValueTemp = KeyValueScan();

	if(GetValueTemp==gKey_Flags.LastKeyValue){
		if(GetValueTemp!=KEY_VALUE_NULL){
			gKey_Flags.KeyCnt++;
			if(gKey_Flags.KeyCnt >= KEY_SCAN_LONG_DOWN_PRESS_CNT){
				gKey_Flags.KeyCnt		= KEY_SCAN_LONG_DOWN_CNT;
				gKey_Flags.KeyValue		= GetValueTemp;
				gKey_Flags.KeyState		= KEY_State_LongDown_Press;
				gKey_Flags.KeyDealFlag	= KEY_VALUE_NEW_FLAG;
			}
			else if(gKey_Flags.KeyCnt == KEY_SCAN_LONG_DOWN_CNT){//����
				gKey_Flags.KeyValue		= GetValueTemp;
				gKey_Flags.KeyState		= KEY_State_LongDown_Press_Start;
				gKey_Flags.KeyDealFlag	= KEY_VALUE_NEW_FLAG;
			}
			else if(gKey_Flags.KeyCnt == KEY_SCAN_DOWN_CNT){//һ�ΰ���(3ms����)
				gKey_Flags.KeyValue		= GetValueTemp;
				gKey_Flags.KeyState		= KEY_State_ShortDown_Press_Start;
				gKey_Flags.KeyDealFlag	= KEY_VALUE_NEW_FLAG;
			}
		}
	}
	else{
		if(GetValueTemp==KEY_VALUE_NULL){
			if(gKey_Flags.KeyCnt >= KEY_SCAN_LONG_DOWN_CNT){
				gKey_Flags.KeyValue		= gKey_Flags.LastKeyValue;
				gKey_Flags.KeyState		= KEY_State_LongDown_Release;
				gKey_Flags.KeyDealFlag	= KEY_VALUE_NEW_FLAG;
			}
			else if(gKey_Flags.KeyCnt >= KEY_SCAN_DOWN_CNT){
				gKey_Flags.KeyValue		= gKey_Flags.LastKeyValue;
				gKey_Flags.KeyState		= KEY_State_ShortDown_Release;
				gKey_Flags.KeyDealFlag	= KEY_VALUE_NEW_FLAG;
			}
		}
		gKey_Flags.KeyCnt = KEY_SCAN_NULL;
	}
	gKey_Flags.LastKeyValue = GetValueTemp;
}

#include "oled.h" 
#include <math.h>
#include "bsp_beep.h"
#include "syn6288.h"
void IndependentKeyDealPro(void)
{
	extern __IO uint32_t light_value;
	extern __IO float humidity_value, temperature_value;
	char humidity[] = "����ʪ����00000000000";
	char temperature[] = "�����¶���0000000000";	
	char light[] = "����ǿ����00000000000";		

	if(gKey_Flags.KeyDealFlag == KEY_VALUE_NEW_FLAG){
		gKey_Flags.KeyDealFlag = KEY_VALUE_NEW_NULL;
		switch(gKey_Flags.KeyValue)
		{
			case KEY_VALUE_ONE:
				switch(gKey_Flags.KeyState)
				{
					case KEY_State_ShortDown_Press_Start:
						GPIO_ResetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);	
						sprintf(light+10, "%-5d""%s", light_value, "�տ�˹");
						syn6288_SpeakStr(light, 1);				
						break;
					case KEY_State_ShortDown_Release:	
						GPIO_SetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);						
						break;
					case KEY_State_LongDown_Press_Start:
						break;
					case KEY_State_LongDown_Press:			
						break;
					case KEY_State_LongDown_Release:
						break;
					default:
						break;
				}
				break;
			case KEY_VALUE_TWO:
				switch(gKey_Flags.KeyState)
				{
					case KEY_State_ShortDown_Press_Start:		
						GPIO_ResetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);		
						sprintf(humidity+10, "%-.2f""%s", humidity_value, "�ٷֶ�");
						syn6288_SpeakStr(humidity, 1);							
						break;
					case KEY_State_ShortDown_Release:
						GPIO_SetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);
						break;
					case KEY_State_LongDown_Press_Start:						
						break;
					case KEY_State_LongDown_Press:				
						break;
					case KEY_State_LongDown_Release:							
						break;
					default:
						break;
				}
				break;
			case KEY_VALUE_THREE:
				switch(gKey_Flags.KeyState)
				{
					case KEY_State_ShortDown_Press_Start:	
						GPIO_ResetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);	
						sprintf(temperature+10, "%-.2f""%s", temperature_value, "���϶�");
						syn6288_SpeakStr(temperature, 1);					
						break;
					case KEY_State_ShortDown_Release:
						GPIO_SetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);
						break;
					case KEY_State_LongDown_Press_Start:
						break;
					case KEY_State_LongDown_Press:
						break;
					case KEY_State_LongDown_Release:
						break;
					default:
						break;
				}
				break;
			default:
				break;
		}
	}
}

void hongwai_init (void)
{

	GPIO_InitTypeDef GPIO_InitStructure;
 
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTA,PORTEʱ��

	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;//KEY0-KEY2
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
 	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOE2,3,4

}



/*********************************************END OF FILE**********************/
