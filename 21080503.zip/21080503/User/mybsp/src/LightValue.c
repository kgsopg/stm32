/* Includes ------------------------------------------------------------------*/
#include "LightValue.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define LIGHT    	   0x46 
/*******************************************************************************
* Function Name  : I2C_LV_Init
* Description    : Initializes the I2C2.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_LV_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	I2C_InitTypeDef   I2C_InitStructure;

	/* GPIOB Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);

	/* I2C1 Periph clock enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);

	/* Configure I2C1 pins: SCL and SDA */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 | GPIO_Pin_11;

	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	I2C_DeInit(I2C2);

	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C; 
	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
	I2C_InitStructure.I2C_OwnAddress1 = 0x00;
	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
	I2C_InitStructure.I2C_ClockSpeed = 100000;
	I2C_Init(I2C2, &I2C_InitStructure);

	I2C_Cmd(I2C2, ENABLE);
	
	I2C_LV_Write(0x01);
}

/*******************************************************************************
* Function Name  : I2C_LV_Write
* Description    : Write to the specified register of the LV.
*******************************************************************************/
void I2C_LV_Write(u16 RegValue)
{
	#define TIMEOUT_MAX 100
	__IO uint32_t timeout = TIMEOUT_MAX;
	while((I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY)!=0)&&(timeout-->0))
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/*----- Transmission Phase -----*/
	/* Send I2C2 START condition */
	I2C_GenerateSTART(I2C2, ENABLE);

	/* Test on I2C2 EV5 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)!=1)&&(timeout-->0))  /* EV5 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Send STLM75 slave address for write */
	I2C_Send7bitAddress(I2C2, LIGHT, I2C_Direction_Transmitter);

	/* Test on I2C2 EV6 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)!=1)&&(timeout-->0)) /* EV6 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Send I2C2 data */
	I2C_SendData(I2C2, (u8)RegValue);

	/* Test on I2C2 EV8 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)!=1)&&(timeout-->0)) /* EV8 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Send I2C2 STOP Condition */
	I2C_GenerateSTOP(I2C2, ENABLE);    
}

/*******************************************************************************
* Function Name  : I2C_LM75_Temp_Read
* Description    : Read Temperature register of LM75: double temperature value.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
u16 I2C_LV_Read(void)
{
	#define TIMEOUT_MAX 100
	__IO uint32_t timeout = TIMEOUT_MAX;
	u32 RegValue = 0,RegValue2 = 0;
	while((I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY)!=0)&&(timeout-->0))
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Enable I2C2 acknowledgement if it is already disabled by other function */
	I2C_AcknowledgeConfig(I2C2, ENABLE);

	/*----- Reception Phase -----*/
	/* Send Re-STRAT condition */
	I2C_GenerateSTART(I2C2, ENABLE);

	/* Test on EV5 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)!=1)&&(timeout-->0))  /* EV5 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Send STLM75 slave address for read */
	I2C_Send7bitAddress(I2C2, LIGHT, I2C_Direction_Receiver);

	/* Test on EV6 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)!=1)&&(timeout-->0))  /* EV6 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;	
	/* Test on EV7 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)!=1)&&(timeout-->0))  /* EV7 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Store I2C2 received data */
	RegValue = I2C_ReceiveData(I2C2);
	/* Disable I2C2 acknowledgement */
	I2C_AcknowledgeConfig(I2C2, DISABLE);		 //  I2C2->CR1 |= ((u16)0x0400);
	/* Send I2C2 STOP Condition */			
	I2C_GenerateSTOP(I2C2, ENABLE);			 //  I2C2->CR1 |= ((u16)0x0200);

	/* Test on EV7 and clear it */
	while((I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)!=1)&&(timeout-->0))  /* EV7 */
	{
	}
	if(0==timeout){//��ʱ����
		timeout = TIMEOUT_MAX;//�˴�δ����
	}else
		timeout = TIMEOUT_MAX;
	/* Store I2C2 received data */
	RegValue2= I2C_ReceiveData(I2C2);

	/* Test on EV7 and clear it */
	//  while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED))  /* EV7 */
	//  {printf("6");
	//  }
	/* Enable I2C2 acknowledgement if it is already disabled by other function */
	I2C_AcknowledgeConfig(I2C2, ENABLE);

	return (RegValue=(RegValue<<8)|RegValue2 );
}
