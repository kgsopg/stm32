#include "bsp_adc.h"

__IO uint32_t ADC_ConvertedValue[ADC1_BufferLength] = {0};
static void ADC_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Enable DMA clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	
	/* Enable ADC1, ADC2 and GPIOA clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_ADC2 | RCC_APB2Periph_GPIOA, ENABLE);
	
	/* Configure PA0, PA1 as analog input */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

static void ADC_Mode_Config(void)
{
	DMA_InitTypeDef DMA_InitStructure;
	ADC_InitTypeDef ADC_InitStructure;
	
	/* DMA channel1 configuration */
	DMA_DeInit(DMA1_Channel1);
	
	DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address; 			
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&ADC_ConvertedValue;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = ADC1_BufferLength;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;  		
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;	
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;										
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);
	
	DMA_ClearITPendingBit(DMA_IT_TC); 
	DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
	/* Enable DMA channel1 */
	DMA_Cmd(DMA1_Channel1, ENABLE);
	
	ADC_DeInit(ADC1);
	ADC_DeInit(ADC2);  
	/* ADC1 configuration */	
	ADC_InitStructure.ADC_Mode = ADC_Mode_RegSimult;			
	ADC_InitStructure.ADC_ScanConvMode = ENABLE ; 	 			
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;			
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;	
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right; 	
	ADC_InitStructure.ADC_NbrOfChannel = NOFCHANEL;	 	
	ADC_Init(ADC1, &ADC_InitStructure);
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);//12M

	ADC_RegularChannelConfig(ADC1, 
							 ADC_Channel_0,
							 1, 
							 ADC_SampleTime_239Cycles5);			 
	/* Enable ADC1 DMA */
	ADC_DMACmd(ADC1, ENABLE);
	
	/* ADC2 configuration */	
	ADC_Init(ADC2, &ADC_InitStructure);
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);//12M

	ADC_RegularChannelConfig(ADC2, 
							ADC_Channel_1,
							1, 
							ADC_SampleTime_239Cycles5);	
	ADC_ExternalTrigConvCmd(ADC2, ENABLE);/* ʹ��ADC2���ⲿ����ת�� */
	/* Enable ADC1 */
	ADC_Cmd(ADC1, ENABLE);
	ADC_ResetCalibration(ADC1);	/*��λУ׼�Ĵ��� */  
	while(ADC_GetResetCalibrationStatus(ADC1));
	
	ADC_StartCalibration(ADC1);/* ADCУ׼ */
	while(ADC_GetCalibrationStatus(ADC1));
	
	ADC_Cmd(ADC2, ENABLE);
	ADC_ResetCalibration(ADC2);	/*��λУ׼�Ĵ��� */  
	while(ADC_GetResetCalibrationStatus(ADC2));
	
	ADC_StartCalibration(ADC2);/* ADCУ׼ */
	while(ADC_GetCalibrationStatus(ADC2));	
	
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);//��������
}

static void ADC_DOG_Set(void)//��������
{     
	#define VOLTAGE_HighThreshold 3900
	#define VOLTAGE_LowThreshold  0x0
	ADC_AnalogWatchdogSingleChannelConfig(ADC1, ADC_Channel_0);//���ÿ��Ź�ADCͨ��
	ADC_AnalogWatchdogThresholdsConfig(ADC1, VOLTAGE_HighThreshold, VOLTAGE_LowThreshold);
	ADC_AnalogWatchdogCmd(ADC1, ADC_AnalogWatchdog_SingleRegEnable);
	ADC_ITConfig(ADC1, ADC_IT_AWD, ENABLE);    
}

void ADC12_Init(void)
{
	ADC_GPIO_Config();
	ADC_Mode_Config();
	ADC_DOG_Set();
}

__IO float IL_S[2] = {0.0, 0.0};
void Que()
{
	unsigned short int Max_ia=0;
	unsigned short int Min_ia=ADC_ConvertedValue[0]&0XFFFF;
	unsigned short int Max_ib=0;
	unsigned short int Min_ib=(ADC_ConvertedValue[0]&0XFFFF0000) >> 16;
	unsigned int temp_ia=0;
	unsigned int temp_ib=0;
	unsigned short int temp_iaa=0;
	unsigned short int temp_ibb=0;
	unsigned char temp_iandex = 0;
	for(temp_iandex = 0; temp_iandex < ADC1_BufferLength; temp_iandex ++)
	{
		temp_iaa = ADC_ConvertedValue[temp_iandex]&0XFFFF;
		temp_ibb = (ADC_ConvertedValue[temp_iandex]&0XFFFF0000) >> 16;
		if(temp_iaa>Max_ia)   
			Max_ia=temp_iaa;
		else if(temp_iaa<Min_ia)  
			Min_ia=temp_iaa; 

		if(temp_ibb>Max_ib)  
			Max_ib=temp_ibb;
		else if(temp_ibb<Min_ib)   
			Min_ib=temp_ibb;
	}  
	for(temp_iandex = 0; temp_iandex < ADC1_BufferLength; temp_iandex ++)
	{
		temp_ia+=(ADC_ConvertedValue[temp_iandex]&0XFFFF);
		temp_ib+=((ADC_ConvertedValue[temp_iandex]&0XFFFF0000) >> 16);
	} 

	IL_S[0]=(uint16_t)((temp_ia-Max_ia-Min_ia)>>3); 
	IL_S[1]=(uint16_t)((temp_ib-Max_ib-Min_ib)>>3); 
} 

/*********************************************END OF FILE**********************/
