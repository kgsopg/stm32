#include "main.h"

uint8_t show_task = 0;
extern __IO float IL_S[2];
__IO uint32_t light_value = 0;
__IO float humidity_value = 0.0, temperature_value = 0.0;
 u8  dir1=0,dir2=0;
 u16 duoji1,duoji2;
/*
 * PROTOTYPES
 */
static void initializeHardware(void);
static void displaytitle(void);
static void displayinfo(void);
static void LED_control(int red,int green,int blue);
static void check_status(void);
static void check_light(void);
static void check_humidity(void);
static void sevor_control(void);
static void main_delay(__IO uint32_t numLoops);

/*
 * FUNCTIONS
 */
//TODO: (T_T)
int main(void)
{
	DisableInterrupts
	initializeHardware();
	SetIrq_Priority();
	EnableInterrupts

	displaytitle();
	main_delay(0x0ffffe);

	for(;;) { 
		if(1==show_task) {
			show_task = 0;
			displayinfo();
		}		
		check_light();
		check_humidity();
	//	check_status();		
		sevor_control();
			GPIO_SetBits(GPIOC, GPIO_Pin_13);		
	}
}

static void initializeHardware(void)
{
	duoji1=160;
	duoji2=100;
	bsp_InitTimer();
	OLED_Init();/* SCK->A5, SDA->A7, DC->A4, RST->A6, CS->GND */
	BEEP_Init();/* BEEP->B8 */
	USART1_Config(115200);/* TX->B6, RX->B7 */
	SYN6288_Init() ;/* TX->A2, RX->A3 */
	DS18B20_Init();/* temp->B15 */
	I2C_LV_Init();/* SCL->B10, SDA->B11 */
	LED_GPIO_Config();/* DS0->C13, LoRa_M0->B4, LoRa_M1->B5 */
	Key_GPIO_Config();/* KEY0->A12, KEY1->A15, KEY2->B9 */
	ADC12_Init();/* CH0->A0 for soil, CH1->A1 for duiguan */
	hongwai_init();
  TIM3_PWM_Init();/* (50Hz) for steering, CH3->B0, CH1->B1 */
	ADVANCE_TIM1_PWM_Init();/* A8, A9, A10 for breathing light, A11 for motor*/
	                     /* C14, C15 for RTC*/
	TIM_SetCompare3(TIM3,160);
	TIM_SetCompare4(TIM3,100);
	TIM4_1msIRQ_Config(5);/* 250ms to refresh the screen */
	/*
	used:
	A: 0 1 2 3 4 5 6 7 8 9 10 11 12 15
	B: 0 1 4 5 6 7 8 9 10 11 15
	C: 13 14 15
	rest: 
	B3 B12 B13 B14
	*/
}
static void displaytitle(void)
{
	syn6288_SpeakStr("�ǻ۴���", 1);
	OLED_P14x16Str(36, 0, (uint8_t *)"�ǻ۴���");
	OLED_P6x8Str(0, 3, (uint8_t *)"light: 0    lx");//light intensity
	OLED_P6x8Str(0, 4, (uint8_t *)"humidity: 0    H");
	OLED_P6x8Str(0, 5, (uint8_t *)"temperature: 0    C");
//	OLED_P6x8Str(0, 6, (uint8_t *)"frequency: 50.00 Hz");
}

static void displayinfo(void)
{
	/* Show the humidity of Soil */
	humidity_value	= (float)(100.0-30*IL_S[0]/4096*3.3);
	OLED_Print_num_float(52, 4, humidity_value, 2);
	
	/* Show the temperature of Soil */
	temperature_value = DS18B20_Get_Temp();
	OLED_Print_num_float(72, 5, temperature_value, 1);
	OLED_P6x8Str(108, 5, (uint8_t *)"C");//��ֹ�¶���������ʱ��Ĩ��
	
	/* Get double of Light value */
	I2C_LV_Write(0x11);
	light_value = (uint32_t)(I2C_LV_Read()/1.2);
	OLED_Print_num_int(36, 3, light_value);
	
	/***************LoRa****************/
	printf("The humidity of soil is %.3f H\r\n", humidity_value);
	Delay_ms(400);
	printf("The temperature of soil is %.3f ��C\r\n", temperature_value);	
	Delay_ms(400);
	printf("The light value is %5d lx\r\n", light_value);
	Delay_ms(400);
	printf("\r\n");
	Delay_ms(400);
	/**********************************/
}

static void LED_control(int red,int green,int blue)
{
	TIM_SetCompare1(TIM1,red);
	TIM_SetCompare2(TIM1,green);
	TIM_SetCompare3(TIM1,blue);
}
static void sevor_control(void)
{
  
	if(dir1)
	{	
  	duoji1=duoji1+1;
	}
	else
	{
	  duoji1=duoji1-1;
	}

  if(duoji1>200)	dir1=0;
	if(duoji1<100)  dir1=1;
	
	if(dir2)
	{	
  	duoji2=duoji2+1;
	}
	else
	{
	  duoji2=duoji2-1;
	}
	
	if(duoji2>150)	dir2=0;
	if(duoji2<130)  dir2=1;
	TIM_SetCompare3(TIM3,duoji1);
	TIM_SetCompare4(TIM3,duoji2);
	Delay_ms(15);

}



static void check_status(void)
{
	if(Hongwai==1&&(temperature_value>30.0||humidity_value<50))
	{
		LED_control(0,1000,0);
		syn6288_SpeakStr("����״̬����", 1);
		beep_change(1);
	}
	else if(Hongwai==1&&temperature_value<30.0&&humidity_value>50)
	{
		LED_control(0,0,0);
		syn6288_SpeakStr("����״̬����", 1);	
		beep_change(0);
	}
}		

static void check_light(void)
{
  if(temperature_value<25)
	{
	  LED_control(1000,1000,1000);
	}
	else if((temperature_value>25)&&(temperature_value<30))
  {
	  LED_control(700,500,500);
	}
	else if((temperature_value>30)&&(temperature_value<35))
	{
	  LED_control(0,700,700);
	}
	else if((temperature_value>35)&&(temperature_value<40))
	{
	 LED_control(700,700,0);
	}
	else if((temperature_value>40)&&(temperature_value<45))
	{
	 LED_control(700,0,700);
	}
	else if((temperature_value>45)&&(temperature_value<50))
	{
	 
		LED_control(500,0,0);
	}
	else
	{
		LED_control(100,100,0);
	 
	}

}
static void check_humidity(void)
{
	if(humidity_value<60)
			GPIO_SetBits(GPIOC, GPIO_Pin_13);
	else
			GPIO_ResetBits(GPIOC, GPIO_Pin_13);
}
/*how to use: e.g. main_delay(100)*/
static void main_delay(__IO uint32_t numLoops)
{
	for(; numLoops != 0; numLoops--);
}
/*********************************************END OF FILE**********************/
