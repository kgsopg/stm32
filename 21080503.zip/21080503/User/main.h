#ifndef __MAIN_H__
#define __MAIN_H__

#include "stm32f10x.h"
#include "stm32f10x_it.h"

#include "oled.h"
#include "bsp_led.h"
#include "bsp_key.h" 
#include "ds18b20.h"
#include "syn6288.h"
#include "LightValue.h"
#include "bsp_adc.h"
#include "bsp_beep.h"
#include "bsp_SysTick.h"
#include "bsp_usart.h"
#include "bsp_TimGp.h"
#include "bsp_AdvTim.h" 


#define EnableInterrupts  	__set_PRIMASK(0);	
#define DisableInterrupts	__set_PRIMASK(1);	

#define   sevro_motor_up   1700
#define   sevro_motor_down  1400
#define   sevro_motor_left   1700
#define   sevro_motor_right  1400


#endif
